#include<stdio.h>
#include<stdlib.h>
struct node
{
    int info;
    struct node*llink;
    struct node*rlink;
};
typedef struct node* NODE;
NODE getnode()
{
    NODE x;
    x=(NODE)malloc(sizeof(struct node));
    if(x==NULL)
    {
        printf("Memory not allocated");
        exit(0);
    }
    return x;
}
NODE insert(NODE root,int item)
{
 NODE temp,prev,cur;
 temp=getnode();
 temp->info=item;
 temp->llink=temp->rlink=NULL;
 if(root==NULL)
 {
     return temp;
 }
 prev=NULL;
 cur=root;
 while(cur!=NULL)
 {
     prev=cur;
     if(cur->info>item)
     {
         cur=cur->llink;
     }
     else
     {
         cur=cur->rlink;
     }
 }
 if(prev->info<item)
 {
     prev->rlink=temp;
 }
 else
 {
     prev->llink=temp;
 }
 return root;
}
void preorder(NODE root)
{
    if(root==NULL)
    {
        return;
    }
    printf("%d\t",root->info);
    preorder(root->llink);
    preorder(root->rlink);
}
void inorder(NODE root)
{
    if(root==NULL)
    {
        return;
    }
    inorder(root->llink);
    printf("%d\t",root->info);
    inorder(root->rlink);
}
void postorder(NODE root)
{
    if(root==NULL)
    {
        return;
    }
    postorder(root->llink);
    postorder(root->rlink);
    printf("%d\t",root->info);
}
void search(NODE root,int item)
{
    NODE cur;
    cur=root;
    if(cur==NULL)
    {
        printf("Empty tree\n");
        return;
    }
    while(cur!=NULL)
    {
        if(cur->info==item)
        {
            printf("Element exists\n");
            return;
        }
        if(cur->info>item)
        {
            cur=cur->llink;
        }
        else
        {
            cur=cur->rlink;    
        }
    }
    printf("Element does not exist\n");
}
int main()
{
    NODE root=NULL;
    int item,i;
    int ch,n;
    printf("Enter number of nodes in BST\n");
    scanf("%d",&n);
    printf("Enter elements of binary search tree\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&item);
        root=insert(root,item);
    }
    while(1)
    {
        printf("\n1.Preorder\n2.Inorder\n3.Postorder\n4.search\n5.exit\nEnter your choice\n");
        scanf("%d",&ch);
        switch(ch)
        {
         case 1:
         printf("Preorder\n");
         preorder(root);
         break;
         case 2:
         printf("Inorder\n");
         inorder(root);
         break;
         case 3:
         printf("Postorder\n");
         postorder(root);
         break;
         case 4:
         printf("Enter the element to be searched");
         scanf("%d",&item);
         search(root,item);
         break;
         default:
         exit(0);
        }
    }
}
