#include<stdio.h>
#include<stdlib.h>
#include<math.h>
struct poly
{
    int cf,px,py,pz;
    struct poly*link;
};
typedef struct poly* P;
P getnode()
{
    P temp;
    temp=(P)malloc(sizeof(struct poly));
    if(temp==NULL)
    {
        printf("Memory not allocated");
        exit(0);
    }
    return temp;
}
void read_poly(P p1,int n)
{
    P temp,next;
    int i;
    for(i=0;i<n;i++)
    {
        temp=getnode();
        printf("Enter the cf,px,py,pz");
        scanf("%d%d%d%d",&(temp->cf),&(temp->px),&(temp->py),&(temp->pz));
        next=p1->link;
        p1->link=temp;
        temp->link=next;
    }
}
void display(P head)
{
    P cur;
    cur=head->link;
    printf("Elements of polynomial");
    while(cur!=head)
    {
        if(cur->cf>0)
        {
            printf("+%dx^%dy^%dz^%d",cur->cf,cur->px,cur->py,cur->pz);
        }
        else
        {
           printf("%dx^%dy^%dz^%d",cur->cf,cur->px,cur->py,cur->pz); 
        }
        cur=cur->link;
    }
    printf("\n");
}
P compare(P term,P p2)
{
    P cur;
    cur=p2->link;
    while(cur!=p2)
    {
        if(cur->px==term->px&&cur->py==term->py&&cur->pz==term->pz)
        {
            return cur;
        }
        cur=cur->link;
    }
    return NULL;
}
void insert_poly(P p3,int cf,int px,int py,int pz)
{
    P temp,next;
    temp=getnode();
    temp->cf=cf;
    temp->px=px;
    temp->py=py;
    temp->pz=pz;
    next=p3->link;
    p3->link=temp;
    temp->link=next;
}
void add_poly(P p1,P p2,P p3)
{
    P res,cur;
    cur=p1->link;
    while(cur!=p1)
    {
        res=compare(cur,p2);
        if(res!=NULL)
        {
            insert_poly(p3,cur->cf+res->cf,cur->px,cur->py,cur->pz);
            res->cf=-999;
        }
        else
        {
            insert_poly(p3,cur->cf,cur->px,cur->py,cur->pz);
        }
        cur=cur->link;
    }
    cur=p2->link;
    while(cur!=p2)
    {
        if(cur->cf!=-999)
        {
            insert_poly(p3,cur->cf,cur->px,cur->py,cur->pz);
        }
        cur=cur->link;
    }
}
void evaluate(P p1)
{
    int x,y,z,res=0;
    P cur;
    printf("Enter values of x,y,z");
    scanf("%d%d%d",&x,&y,&z);
    cur=p1->link;
    while(cur!=p1)
    {
        res=res+cur->cf*pow(x,cur->px)*pow(y,cur->py)*pow(z,cur->pz);
        cur=cur->link;
    }
    printf("Evaluation of polynomial is %d\n",res);
}
int main()
{
    P p1,p2,p3,p4;
    p1=getnode();
    p2=getnode();
    p3=getnode();
    p4=getnode();
    p1->link=p1;
    p2->link=p2;
    p3->link=p3;
    p4->link=p4;
    int n1,n2;
    int ch;
    while(1)
    {
        printf("1.Evaluate\n2.Addition\n3.Exit\nEnter your choice\n");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1:printf("Enter number of terms in polynomial p1");
                   scanf("%d",&n1);
                   read_poly(p1,n1);
                   display(p1);
                   evaluate(p1);
                   break;
            case 2: printf("Enter number of terms in polynomial p2 and p3");
                    scanf("%d%d",&n1,&n2);
                    read_poly(p2,n1);
                    display(p2);
                    read_poly(p3,n2);
                    display(p3);
                    add_poly(p2,p3,p4);
                    printf("After addition\n");
                    display(p4);
                    break;
            default:exit(0);
        }
    }
}


