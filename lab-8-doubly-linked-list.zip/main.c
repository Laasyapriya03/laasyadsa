#include<stdio.h>
#include<stdlib.h>
struct node
{
    int ssn;
    char name[50],dept[50],desig[50];
    float sal;
    long int ph;
    struct node*llink;
    struct node*rlink;
};
typedef struct node*NODE;
NODE getnode()
{
    NODE x;
    x=(NODE)malloc(sizeof(struct node));
    if(x==NULL)
    {
        printf("Memory not allocated");
        exit(0);
    }
    return x;
}
NODE insert_front(NODE first)
{
    NODE temp;
    temp=getnode();
    temp->llink=temp->rlink=NULL;
    printf("Enter ssn,name,dept,desig,sal,ph");
    scanf("%d%s%s%s%f%ld",&temp->ssn,temp->name,temp->dept,temp->desig,&temp->sal,&temp->ph);
    if(first==NULL)
    {
        return temp;
    }
    else
    {
    temp->rlink=first;
    first->llink=temp;
    return temp;
    }
}
NODE insert_rear(NODE first)
{
    NODE temp,cur;
    cur=first;
    temp=getnode();
    temp->llink=temp->rlink=NULL;
    printf("Enter ssn,name,dept,desig,sal,ph");
    scanf("%d%s%s%s%f%ld",&temp->ssn,temp->name,temp->dept,temp->desig,&temp->sal,&temp->ph);
    if(first==NULL)
    {
        return temp;
    }
    while(cur->rlink!=NULL)
    {
    cur=cur->rlink;
    }
    cur->rlink=temp;
    temp->llink=cur;
    return first;
}
NODE delete_front(NODE first)
{
    NODE next;
    if(first==NULL)
    {
        printf("DLL is empty");
        return first;
    }
    next=first->rlink;
    printf("Deleted employee details");
    printf("%d%s%s%s%f%ld",first->ssn,first->name,first->dept,first->desig,first->sal,first->ph);
    free(first);
    return next;
}
NODE delete_rear(NODE first)
{
    NODE prev,cur;
    prev=NULL;
    cur=first;
    if(first==NULL)
    {
        printf("DLL is empty");
        return first;
    }
    if(first->rlink==NULL)
    {
        printf("Deleted employee details");
        printf("%d%s%s%s%f%ld",first->ssn,first->name,first->dept,first->desig,first->sal,first->ph);
        free(first);
        return NULL;
    }
    while(cur->rlink!=NULL)
    {
        prev=cur;
        cur=cur->rlink;
    }
    printf("Deleted employee details");
    printf("%d%s%s%s%f%ld",cur->ssn,cur->name,cur->dept,cur->desig,cur->sal,cur->ph);
    free(cur);
    prev->rlink=NULL;
    return first;
}
void count(NODE first)
{
    int count=0;
    NODE cur;
    cur=first;
    while(cur!=NULL)
    {
        count++;
        cur=cur->rlink;
    }
    printf("Number of nodes %d",count);
}
void display(NODE first)
{
NODE cur;
cur=first;
if(first==NULL)
{
    printf("Empty dll");
    return;
}
while(cur!=NULL)
{
    printf("%d%s%s%s%f%ld",cur->ssn,cur->name,cur->dept,cur->desig,cur->sal,cur->ph);
    cur=cur->rlink;
}
}
NODE create(NODE first)
{
    int i,n;
    printf("enter number of employees");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        first=insert_rear(first);
    }
    return first;
}
int main()
{
    NODE first=NULL;
    int ch,n;
    while(1)
    {
        printf("1.create\n2.count\n3.insert_front\n4.insert_rear\n5.delete_front\n6.delete_rear\n7.display\n8.double ended queue\n9.Exit\nEnter your choice");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1:first=create(first);
                   break;
            case 2:count(first);
                   break;
            case 3:first=insert_front(first);
                   break;
            case 4:first=insert_rear(first);
                   break;
            case 5:first=delete_front(first);
                   break;
            case 6:first=delete_rear(first);
                   break;
            case 7:display(first);
                   break;
            case 8:printf("Enter your choice\n1.enqueue\n 2.dequeue\n3.exit");
                   scanf("%d",&n);
                   switch(n)
                   {
                       case 1:insert_rear(first);
                              break;
                       case 2:delete_front(first);
                              break;
                       case 3:exit(0);
                   }
                   break;
            default:exit(0);
        }
    }
}