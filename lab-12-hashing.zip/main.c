#include<stdio.h>
#include<stdlib.h>
#define HZ 3 
struct employee
{
    int empno;
    char name[20];
    int sal;
};
typedef struct employee EMP;
struct hashtable
{
    int key;
    long int addr;
};
typedef struct hashtable ht;
int hashval(int empno)
{
    return empno%HZ;
}
void insert(FILE*fp,ht*h,int n)
{
    EMP a;
    int i,hindex,countindex;
    printf("Enter empno,name,sal");
    scanf("%d%s%d",&(a.empno),a.name,&(a.sal));
    hindex=hashval(a.empno);
    countindex=hindex;
    while(h[hindex].key!=-1)
    {
        hindex=(hindex+1)%HZ;
        if(hindex==countindex)
        {
            printf("Insertion not possoible");
            return;
        }
    }
    h[hindex].key=a.empno;
    fseek(fp,0,SEEK_END);
    h[hindex].addr=ftell(fp);
    fwrite(&a,sizeof(EMP),1,fp);
    printf("%d%s%d%ld",a.empno,a.name,a.sal,h[hindex].addr);
}
void display(FILE *fp,ht*h,int n)
{
    EMP a;
    int i;
    for(i=0;i<HZ;i++)
    {
        printf("i=%d h[hindex].key=%d\n",i,h[i].key);
        if(h[i].key!=-1)
        {
            fseek(fp,h[i].addr,SEEK_SET);
            fread(&a,sizeof(EMP),1,fp);
            printf("%d%s%d%ld",a.empno,a.name,a.sal,h[i].addr);
        }
    }
    
}
void  search(FILE*fp,ht*h,int n)
{
    EMP a;
    int countindex,hindex;
    printf("Enter empno to be searched");
    scanf("%d",&(a.empno));
    hindex=hashval(a.empno);
    countindex=hindex;
    while(h[hindex].key!=a.empno)
    {
        hindex=(hindex+1)%HZ;
        if(countindex==hindex)
        {
        printf("search unsuccessful");
        return;
        }
    }
    fseek(fp,h[hindex].addr,SEEK_SET);
    fread(&a,sizeof(EMP),1,fp);
    printf("Employee details found");
    printf("%d%s%d",a.empno,a.name,a.sal);
}
int main()
{
    FILE *fp;
    ht h[HZ];
    int i,n,ch;
    fp=fopen("k1.txt","w+");
    for(i=0;i<HZ;i++)
            h[i].key=-1;
    while(1)
    {
        printf("1.Insert\n2.Display\n3.Search\n4.exit\nEnter your choice");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1:printf("Enter number of employees");
            scanf("%d",&n);
            insert(fp,h,n);
            break;
            case 2:
            display(fp,h,n);
            break;
            case 3:
            search(fp,h,n);
            break;
            default:exit(0);
        }
    }
}