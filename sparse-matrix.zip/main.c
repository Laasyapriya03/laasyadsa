#include<stdio.h>
#include<stdlib.h>
typedef struct
{
    int row;
    int col;
    int val;
}s;
s a[10];
void accept(s a[10],int n,int m)
{
    int i,j,k=1,elem;
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            printf("Enter the element for row %d and col %d\n",i,j);
            scanf("%d",&elem);
            if(elem!=0)
            {
                a[k].row=i;
                a[k].col=j;
                a[k].val=elem;
                k++;
            }
        }
    }
    a[0].row=n;
    a[0].col=m;
    a[0].val=k-1;
}
void display(s a[10])
{
    int i,j,m,n,k=1;
    n=a[0].row;
    m=a[0].col;
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            if((i==a[k].row)&&(j==a[k].col)&&(k<=a[0].val))
            {
                printf("%d\t",a[k].val);
                k++;
            }
            else
            {
                printf("0\t");
            }
        }
        printf("\n");
    }
}
void transpose(s a[10],s b[10])
{
int j,i,k=1;
for(j=0;j<=a[0].col;j++)
{
for(i=1;i<=a[0].val;i++)
{
if(j==a[i].col)
{
b[k].row=a[i].col;
b[k].col=a[i].row;
b[k].val=a[i].val ;
k++;
}
}
}
b[0].row=a[0].col;
b[0].col=a[0].row;
b[0].val=a[0].val;
}
int main()
{
    s a[10],t[10];
    int n=3,m=3;
    accept(a,n,m);
    display(a);
    transpose(a,t);
    printf("Transposed matrix\n");
    display(t);
}